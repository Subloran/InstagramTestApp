//
//  AdaptiveAlert.m
//  InstagramTestApp
//
//  Created by Interaktive Bank Ltd on 06/10/15.
//  Copyright © 2015 Artem. All rights reserved.
//

#import "AlertController.h"

NSString* HideAllAlertsNotification = @"HideAllAlertsNotification";
NSString* HideAllActionSheetsNotification = @"HideAllActionSheetsNotification";

@interface UIAlertView (Hiding)

- (void)hideOnNotification;

@end

@interface UIActionSheet (Hiding)

- (void)hideOnNotification;

@end

@interface UIAlertController (Hiding)

- (void)hideOnNotification;

@end

@implementation UIAlertView (Hiding)

- (void)hideOnNotification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self dismissWithClickedButtonIndex:INT_MAX animated:NO];
}

@end

@implementation UIActionSheet (Hiding)

- (void)hideOnNotification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self dismissWithClickedButtonIndex:INT_MAX animated:NO];
}

@end

@implementation UIAlertController (Hiding)

- (void)hideOnNotification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self dismissViewControllerAnimated:NO completion:nil];
}

@end

@implementation AlertAction

@synthesize title;
@synthesize handler;

+ (instancetype)alertActionWithTitle:(NSString*)titleString andHandler:(AlertActionHandler)handlerBlock
{
    if(titleString.length == 0)
    {
        NSLog(@"AlertAction: Cannot construct action with empty title!");
        return nil;
    }
    
    AlertAction* action = [[AlertAction alloc] init];
    [action setTitle:titleString];
    [action setHandler:handlerBlock];
    
    return action;
}

- (void)setTitle:(NSString*)titleString
{
    title = titleString;
}

- (void)setHandler:(AlertActionHandler)handlerBlock
{
    handler = handlerBlock;
}

@end

static NSMutableSet* activeAlertControllers;

@implementation AlertController

@synthesize title;
@synthesize message;
@synthesize displayStyle;
@synthesize otherActions;
@synthesize textFields;

- (AlertViewStyle)alertViewStyle
{
    return alertViewStyle;
}

- (void)setAlertViewStyle:(AlertViewStyle)style
{
    if(style != alertViewStyle)
    {
        alertViewStyle = style;
        [textFields removeAllObjects];
        if(style == AlertViewStylePlainTextInput)
            [textFields addObject:[[UITextField alloc] initWithFrame:CGRectZero]];
        else if(style == AlertViewStylePlainTextInput)
        {
            UITextField* textfield = [[UITextField alloc] initWithFrame:CGRectZero];
            textfield.secureTextEntry = YES;
            [textFields addObject:textfield];
        }
        else if(style == AlertViewStyleLoginAndPasswordInput)
        {
            [textFields addObject:[[UITextField alloc] initWithFrame:CGRectZero]];
            UITextField* textfield = [[UITextField alloc] initWithFrame:CGRectZero];
            textfield.secureTextEntry = YES;
            [textFields addObject:textfield];
        }
    }
}

+ (instancetype)alertControllerWithTitle:(NSString*)title message:(NSString*)message
                          preferredStyle:(AlertControllerStyle)preferredStyle
{
    if(preferredStyle == AlertControllerStyleAlert && title.length == 0 && message.length == 0)
    {
        NSLog(@"AlertController: Cannot construct alert with empty title and message!");
        return nil;
    }
    
    AlertController* controller = [[AlertController alloc] init];
    [controller setTitle:title];
    [controller setMessage:message];
    [controller setStyle:preferredStyle];
    
    return controller;
}

+ (void)showAlertWithMessage:(NSString*)message
{
    AlertController* controller = [[AlertController alloc] init];
    [controller setTitle:@""];
    [controller setMessage:message];
    [controller setStyle:AlertControllerStyleAlert];
    controller.cancelAction = [AlertAction alertActionWithTitle:@"OK" andHandler:nil];
    [controller show];
}

- (id)init
{
    self = [super init];
    
    if(self)
    {
        otherActions = [NSMutableArray array];
        textFields = [NSMutableArray array];
        if(activeAlertControllers == nil)
            activeAlertControllers = [NSMutableSet set];
    }
    
    return self;
}

- (void)setTitle:(NSString*)titleString
{
    title = titleString;
}

- (void)setMessage:(NSString*)messageString
{
    message = messageString;
}

- (void)setStyle:(AlertControllerStyle)style
{
    displayStyle = style;
}

- (void)addAction:(AlertAction*)action
{
    [otherActions addObject:action];
}

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    for(NSInteger i = 0;i < self.textFields.count;i++)
        [(UITextField*)self.textFields[i] setText:[alertView textFieldAtIndex:i].text];
    AlertActionHandler handler = self.cancelAction != nil && buttonIndex == 0 ? self.cancelAction.handler : [self.otherActions[buttonIndex - (self.cancelAction != nil ? 1 : 0)] handler];
    if(handler != nil)
        handler();
    
    alertView.delegate = nil;
    [activeAlertControllers removeObject:self];
}

- (void)actionSheet:(UIActionSheet*)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    AlertActionHandler handler;
    if(self.cancelAction != nil && buttonIndex == actionSheet.cancelButtonIndex)
        handler = self.cancelAction.handler;
    else if(self.destructiveAction != nil && buttonIndex == actionSheet.destructiveButtonIndex)
        handler = self.destructiveAction.handler;
    else
        handler = [self.otherActions[buttonIndex] handler];
    
    if(handler != nil)
        handler();
    
    actionSheet.delegate = nil;
    [activeAlertControllers removeObject:self];
}

- (UIAlertView*)constructAlertView
{
    if(title.length == 0 && SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8"))
        message = [@"\n" stringByAppendingString:message];
    
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:self.cancelAction.title otherButtonTitles:nil];
    
    for(AlertAction* action in self.otherActions)
        [alert addButtonWithTitle:action.title];
    
    if(self.alertViewStyle != AlertViewStyleDefault)
    {
        if(self.alertViewStyle == AlertViewStyleSecureTextInput)
        {
            alert.alertViewStyle = UIAlertViewStyleSecureTextInput;
            [alert textFieldAtIndex:0].text = [textFields[0] text];
            [alert textFieldAtIndex:0].font = [textFields[0] font];
            [alert textFieldAtIndex:0].textColor = [(UITextField*)textFields[0] textColor];
            [alert textFieldAtIndex:0].placeholder = [(UITextField*)textFields[0] placeholder];
            [alert textFieldAtIndex:0].keyboardType = [(UITextField*)textFields[0] keyboardType];
            if ([(UITextField*)textFields[0] delegate] != nil)
                [alert textFieldAtIndex:0].delegate = [(UITextField*)textFields[0] delegate];
        }
        else if(self.alertViewStyle == AlertViewStylePlainTextInput)
        {
            alert.alertViewStyle = UIAlertViewStylePlainTextInput;
            [alert textFieldAtIndex:0].secureTextEntry = [textFields[0] isSecureTextEntry];
            [alert textFieldAtIndex:0].text = [textFields[0] text];
            [alert textFieldAtIndex:0].font = [textFields[0] font];
            [alert textFieldAtIndex:0].textColor = [(UITextField*)textFields[0] textColor];
            [alert textFieldAtIndex:0].placeholder = [(UITextField*)textFields[0] placeholder];
            [alert textFieldAtIndex:0].keyboardType = [(UITextField*)textFields[0] keyboardType];
            if ([(UITextField*)textFields[0] delegate] != nil)
                [alert textFieldAtIndex:0].delegate = [(UITextField*)textFields[0] delegate];
        }
        else if(self.alertViewStyle == AlertViewStyleLoginAndPasswordInput)
        {
            alert.alertViewStyle = UIAlertViewStyleLoginAndPasswordInput;
            [alert textFieldAtIndex:0].text = [textFields[0] text];
            [alert textFieldAtIndex:0].font = [textFields[0] font];
            [alert textFieldAtIndex:0].textColor = [(UITextField*)textFields[0] textColor];
            [alert textFieldAtIndex:0].placeholder = [(UITextField*)textFields[0] placeholder];
            [alert textFieldAtIndex:0].keyboardType = [(UITextField*)textFields[0] keyboardType];
            if ([(UITextField*)textFields[0] delegate] != nil)
                [alert textFieldAtIndex:0].delegate = [(UITextField*)textFields[0] delegate];
            [alert textFieldAtIndex:1].text = [textFields[1] text];
            [alert textFieldAtIndex:1].font = [textFields[1] font];
            [alert textFieldAtIndex:1].textColor = [(UITextField*)textFields[1] textColor];
            [alert textFieldAtIndex:1].placeholder = [(UITextField*)textFields[1] placeholder];
            [alert textFieldAtIndex:1].keyboardType = [(UITextField*)textFields[1] keyboardType];
            if ([(UITextField*)textFields[1] delegate] != nil)
                [alert textFieldAtIndex:1].delegate = [(UITextField*)textFields[1] delegate];
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:alert selector:@selector(hideOnNotification) name:HideAllAlertsNotification object:nil];
    
    return alert;
}

- (UIActionSheet*)constructActionSheet
{
    UIActionSheet* actionSheet = [[UIActionSheet alloc] initWithTitle:title delegate:(id<UIActionSheetDelegate>)self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
    
    for(AlertAction* action in self.otherActions)
        [actionSheet addButtonWithTitle:action.title];
    
    if(self.destructiveAction != nil)
    {
        [actionSheet addButtonWithTitle:self.destructiveAction.title];
        actionSheet.destructiveButtonIndex = actionSheet.numberOfButtons - 1;
    }
    
    if(self.cancelAction != nil)
    {
        [actionSheet addButtonWithTitle:self.cancelAction.title];
        actionSheet.cancelButtonIndex = actionSheet.numberOfButtons - 1;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:actionSheet selector:@selector(hideOnNotification) name:HideAllActionSheetsNotification object:nil];
    
    return actionSheet;
}

- (UIAlertController*)constructAlertController
{
    UIAlertController* alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(displayStyle == AlertControllerStyleAlert ? UIAlertControllerStyleAlert : UIAlertControllerStyleActionSheet)];
    
    if(displayStyle == AlertControllerStyleActionSheet && self.destructiveAction != nil)
    {
        AlertActionHandler handler = self.destructiveAction.handler;
        [alertController addAction:[UIAlertAction actionWithTitle:self.destructiveAction.title style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            if(handler != nil)
                handler();
        }]];
    }
    
    if(displayStyle == AlertControllerStyleAlert && self.alertViewStyle != AlertViewStyleDefault)
    {
        if(self.alertViewStyle == AlertViewStyleSecureTextInput)
            [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                textField.secureTextEntry = YES;
                textField.text = [textFields[0] text];
                textField.font = [textFields[0] font];
                textField.textColor = [(UITextField*)textFields[0] textColor];
                textField.placeholder = [(UITextField*)textFields[0] placeholder];
                textField.keyboardType = [(UITextField*)textFields[0] keyboardType];
                if ([(UITextField*)textFields[0] delegate] != nil)
                    textField.delegate = [(UITextField*)textFields[0] delegate];
            }];
        else if(self.alertViewStyle == AlertViewStylePlainTextInput)
            [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                textField.secureTextEntry = [textFields[0] isSecureTextEntry];
                textField.text = [textFields[0] text];
                textField.font = [textFields[0] font];
                textField.textColor = [(UITextField*)textFields[0] textColor];
                textField.placeholder = [(UITextField*)textFields[0] placeholder];
                textField.keyboardType = [(UITextField*)textFields[0] keyboardType];
                if ([(UITextField*)textFields[0] delegate] != nil)
                    textField.delegate = [(UITextField*)textFields[0] delegate];
            }];
        else if(self.alertViewStyle == AlertViewStyleLoginAndPasswordInput)
        {
            [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                textField.text = [textFields[0] text];
                textField.font = [textFields[0] font];
                textField.textColor = [(UITextField*)textFields[0] textColor];
                textField.placeholder = [(UITextField*)textFields[0] placeholder];
                textField.keyboardType = [(UITextField*)textFields[0] keyboardType];
                if ([(UITextField*)textFields[0] delegate] != nil)
                    textField.delegate = [(UITextField*)textFields[0] delegate];
            }];
            [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                textField.secureTextEntry = YES;
                textField.text = [textFields[1] text];
                textField.font = [textFields[1] font];
                textField.textColor = [(UITextField*)textFields[1] textColor];
                textField.placeholder = [(UITextField*)textFields[1] placeholder];
                textField.keyboardType = [(UITextField*)textFields[1] keyboardType];
                if ([(UITextField*)textFields[1] delegate] != nil)
                    textField.delegate = [(UITextField*)textFields[1] delegate];
            }];
        }
    }
    
    if(self.cancelAction != nil)
    {
        AlertActionHandler handler = self.cancelAction.handler;
        [alertController addAction:[UIAlertAction actionWithTitle:self.cancelAction.title style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            if(handler != nil)
                handler();
        }]];
    }
    
    for(AlertAction* action in self.otherActions)
    {
        AlertActionHandler handler = action.handler;
        [alertController addAction:[UIAlertAction actionWithTitle:action.title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            for(NSInteger i = 0;i < self.textFields.count;i++)
                [(UITextField*)self.textFields[i] setText:[alertController.textFields[i] text]];
            if(handler != nil)
                handler();
        }]];
    }
    
    if(displayStyle == AlertControllerStyleAlert && SYSTEM_VERSION_LESS_THAN(@"8.3"))
        [alertController.view layoutIfNeeded]; //to resume scrolling for large text
    
    [[NSNotificationCenter defaultCenter] addObserver:alertController selector:@selector(hideOnNotification) name:HideAllAlertsNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:alertController selector:@selector(hideOnNotification) name:HideAllActionSheetsNotification object:nil];
    
    return alertController;
}

- (void)show
{
    if(self.displayStyle == AlertControllerStyleAlert)
    {
        if(!isShown)
        {
            isShown = YES;
            
            if(self.cancelAction == nil && self.otherActions.count == 0)
            {
                NSLog(@"AlertController: Alert has to have an action to be shown!");
                return;
            }
            
            if(SYSTEM_VERSION_LESS_THAN(@"8"))
            {
                [activeAlertControllers addObject:self];
                [[self constructAlertView] show];
            }
            else
            {
                UIViewController* presentingController = [UIApplication sharedApplication].delegate.window.rootViewController;
                while(presentingController.presentedViewController != nil)
                    presentingController = presentingController.presentedViewController;
                [presentingController presentViewController:[self constructAlertController] animated:YES completion:nil];
            }
        }
    }
    else
        NSLog(@"AlertController: Cannot use \"show\" method on action sheet, use other methods!");
}

- (void)showFromTabBar:(UITabBar*)view
{
    if(self.displayStyle == AlertControllerStyleActionSheet)
    {
        if(!isShown)
        {
            isShown = YES;
            
            if(SYSTEM_VERSION_LESS_THAN(@"8"))
            {
                [activeAlertControllers addObject:self];
                [[self constructActionSheet] showFromTabBar:view];
            }
            else
            {
                UIViewController* presentingController = [UIApplication sharedApplication].delegate.window.rootViewController;
                while(presentingController.presentedViewController != nil)
                    presentingController = presentingController.presentedViewController;
                [presentingController presentViewController:[self constructAlertController] animated:YES completion:nil];
            }
        }
    }
    else
        NSLog(@"AlertController: Cannot use \"showFromTabBar\" method on alert, use other methods!");
}

- (void)showFromToolbar:(UIToolbar*)view
{
    if(self.displayStyle == AlertControllerStyleActionSheet)
    {
        if(!isShown)
        {
            isShown = YES;
            
            if(SYSTEM_VERSION_LESS_THAN(@"8"))
            {
                [activeAlertControllers addObject:self];
                [[self constructActionSheet] showFromToolbar:view];
            }
            else
            {
                UIViewController* presentingController = [UIApplication sharedApplication].delegate.window.rootViewController;
                while(presentingController.presentedViewController != nil)
                    presentingController = presentingController.presentedViewController;
                [presentingController presentViewController:[self constructAlertController] animated:YES completion:nil];
            }
        }
    }
    else
        NSLog(@"AlertController: Cannot use \"showFromToolbar\" method on alert, use other methods!");
}

- (void)showInView:(UIView*)view
{
    if(self.displayStyle == AlertControllerStyleActionSheet)
    {
        if(!isShown)
        {
            isShown = YES;
            
            if(SYSTEM_VERSION_LESS_THAN(@"8"))
            {
                [activeAlertControllers addObject:self];
                [[self constructActionSheet] showInView:view];
            }
            else
            {
                UIViewController* presentingController = [UIApplication sharedApplication].delegate.window.rootViewController;
                while(presentingController.presentedViewController != nil)
                    presentingController = presentingController.presentedViewController;
                [presentingController presentViewController:[self constructAlertController] animated:YES completion:nil];
            }
        }
    }
    else
        NSLog(@"AlertController: Cannot use \"showInView\" method on alert, use other methods!");
}

- (void)showFromBarButtonItem:(UIBarButtonItem*)item animated:(BOOL)animated
{
    if(self.displayStyle == AlertControllerStyleActionSheet)
    {
        if(!isShown)
        {
            isShown = YES;
            
            if(SYSTEM_VERSION_LESS_THAN(@"8"))
            {
                [activeAlertControllers addObject:self];
                [[self constructActionSheet] showFromBarButtonItem:item animated:animated];
            }
            else
            {
                UIAlertController* alertController = [self constructAlertController];
                UIPopoverPresentationController* popoverPresenter = [alertController popoverPresentationController];
                popoverPresenter.barButtonItem = item;
                
                UIViewController* presentingController = [UIApplication sharedApplication].delegate.window.rootViewController;
                while(presentingController.presentedViewController != nil)
                    presentingController = presentingController.presentedViewController;
                [presentingController presentViewController:alertController animated:YES completion:nil];
            }
        }
    }
    else
        NSLog(@"AlertController: Cannot use \"showFromBarButtonItem\" method on alert, use other methods!");
}

- (void)showFromRect:(CGRect)rect inView:(UIView*)view animated:(BOOL)animated
{
    if(self.displayStyle == AlertControllerStyleActionSheet)
    {
        if(!isShown)
        {
            isShown = YES;
            
            if(SYSTEM_VERSION_LESS_THAN(@"8"))
            {
                [activeAlertControllers addObject:self];
                [[self constructActionSheet] showFromRect:rect inView:view animated:animated];
            }
            else
            {
                UIAlertController* alertController = [self constructAlertController];
                UIPopoverPresentationController* popoverPresenter = [alertController popoverPresentationController];
                popoverPresenter.sourceRect = rect;
                popoverPresenter.sourceView = view;
                
                UIViewController* presentingController = [UIApplication sharedApplication].delegate.window.rootViewController;
                while(presentingController.presentedViewController != nil)
                    presentingController = presentingController.presentedViewController;
                [presentingController presentViewController:alertController animated:YES completion:nil];
            }
        }
    }
    else
        NSLog(@"AlertController: Cannot use \"showFromRect\" method on alert, use other methods!");
}

@end

