//
//  AdaptiveAlert.h
//  InstagramTestApp
//
//  Created by Interaktive Bank Ltd on 06/10/15.
//  Copyright © 2015 Artem. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifndef SYSTEM_VERSION_EQUAL_TO
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#endif
#ifndef SYSTEM_VERSION_GREATER_THAN
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#endif
#ifndef SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#endif
#ifndef SYSTEM_VERSION_LESS_THAN
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#endif
#ifndef SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)
#endif

extern NSString* HideAllAlertsNotification;
extern NSString* HideAllActionSheetsNotification;

typedef void (^AlertActionHandler)();

typedef NS_ENUM(NSInteger, AlertControllerStyle)
{
    AlertControllerStyleActionSheet = 0,
    AlertControllerStyleAlert
};

typedef NS_ENUM(NSInteger, AlertViewStyle)
{
    AlertViewStyleDefault = 0,
    AlertViewStyleSecureTextInput,
    AlertViewStylePlainTextInput,
    AlertViewStyleLoginAndPasswordInput
};

@interface AlertAction : NSObject
{
    NSString* title;
    AlertActionHandler handler;
}

@property (nonatomic, strong, readonly) NSString* title;
@property (nonatomic, strong, readonly) AlertActionHandler handler;

+ (instancetype)alertActionWithTitle:(NSString*)titleString andHandler:(AlertActionHandler)handlerBlock;

@end

@interface AlertController : NSObject
{
    NSString* title;
    NSString* message;
    AlertControllerStyle displayStyle;
    AlertViewStyle alertViewStyle;
    NSMutableArray* otherActions;
    NSMutableArray* textFields;
    BOOL isShown;
}

@property (nonatomic, strong, readonly) NSString* title;
@property (nonatomic, strong, readonly) NSString* message;
@property (nonatomic, readonly) AlertControllerStyle displayStyle;
@property (nonatomic) AlertViewStyle alertViewStyle;
@property (nonatomic, strong) AlertAction* destructiveAction;
@property (nonatomic, strong) AlertAction* cancelAction;
@property (nonatomic, strong, readonly) NSArray* otherActions;
@property (nonatomic, strong, readonly) NSArray* textFields;

+ (instancetype)alertControllerWithTitle:(NSString*)title message:(NSString*)message
                          preferredStyle:(AlertControllerStyle)preferredStyle;

+ (void)showAlertWithMessage:(NSString*)message;

- (void)addAction:(AlertAction*)action;

- (void)show;
- (void)showFromTabBar:(UITabBar*)view;
- (void)showFromToolbar:(UIToolbar*)view;
- (void)showInView:(UIView*)view;
- (void)showFromBarButtonItem:(UIBarButtonItem*)item animated:(BOOL)animated;
- (void)showFromRect:(CGRect)rect inView:(UIView*)view animated:(BOOL)animated;

@end
